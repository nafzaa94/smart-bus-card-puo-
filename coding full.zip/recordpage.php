<?php
include "./connect.php";
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>SMART BUS CARD</title>
</head>

<body>

    <?php

    $sql = "SELECT `Name`, `Email`, `Phone`, `Id_card`, `DestinationFrom`, `DestinationTo`, `Status` FROM `smart-bus-card` WHERE 1";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        // output data of each row

    ?>

        <div class="container">
            <div class="d-flex justify-content-center mt-5">
                <h1>RECORD SMART BUS CARD</h1>
            </div>
            <div class="d-flex justify-content-center mt-3">
                <div>
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Id Card</th>
                                <th scope="col">Destination From</th>
                                <th scope="col">Destination To</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $count = 1;
                            while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                                <tr>
                                    <th scope="row"><?php echo ($count); ?></th>
                                    <td><?php echo $row["Name"] ?></td>
                                    <td><?php echo $row["Email"] ?></td>
                                    <td><?php echo $row["Phone"] ?></td>
                                    <td><?php echo $row["Id_card"] ?></td>
                                    <td><?php echo $row["DestinationFrom"] ?></td>
                                    <td><?php echo $row["DestinationTo"] ?></td>
                                    <td><?php echo $row["Status"] ?></td>
                                </tr>

                            <?php
                                $count++;
                            }

                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>


    <?php

    }

    mysqli_close($conn);

    ?>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>

</html>