<?php

include "./connect.php";

$Status = $_GET["Status"];
$Id_card = $_GET["Id_card"];

//echo ($Status);

$sql = "UPDATE `smart-bus-card` SET `Status`='$Status' WHERE `Id_card` = '$Id_card'";

$result = mysqli_query($conn, $sql);

mysqli_close($conn);
